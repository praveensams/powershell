﻿configuration dsc
    {
    node localhost
        {
        File DownloadPackage        {            	
              Ensure = "Present"              	
              Type = "File"             	
              SourcePath ="https://exprdstrgcdn.blob.core.windows.net/config/test/NewRedis/Web.config?st=2018-09-09T13%3A10%3A20Z&se=2019-09-10T13%3A10%3A00Z&sp=r&sv=2017-04-17&sr=c&sig=6yJIE28GUtX3bEbRqVK1zUkgleuAXh%2BfR6s%2BiIDApLo%3D"            	
              DestinationPath = "D:\web.config"            
            }
        }
    }